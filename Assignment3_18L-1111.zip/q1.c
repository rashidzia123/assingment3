#include<semaphore.h>
#include <stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<stdbool.h>
int potentialCPatients =0;
int coronaPatient = 0;
sem_t m;
int fluPatient = 0;

struct data
{
	int pid;
	int result;
};
bool test(int sample)
{
    if(sample==1)
    return true;
    else
    return false;
}

void* handle(void * var)
{
    potentialCPatients++;
    struct data *v = (struct data*)var;
   struct data in = *v;
   printf("\n");
    int count = 1;
    
    	printf("patient id: %d\n",in.pid);
    	 printf("test %d\n",count);
    	 if(in.pid)
       {  printf("result: Infected\n");
	coronaPatient++;
	}else{
	printf("result: not Infected\n");
         printf("-----------------------\n");
         fluPatient++;
         printf("\n");
         pthread_exit(0);
         }
         printf("-----------------------\n");
         sem_wait(&m);
    while(test(rand()%3))
    {
    	count++;
    	printf("patient id: %d\n",in.pid);
    	 printf("test %d\n",count);
    	 
         printf("result: Infected\n");
         printf("-----------------------\n");
        
        //csignal();
        
    }
    {
         count++;
         printf("patient id: %d\n",in.pid);
         printf("test %d\n",count);
          printf("result: not Infected\n");
          printf("-----------------------\n");
          coronaPatient--;
        sem_post(&m);
    }
    potentialCPatients--;
    printf("\n");
	pthread_exit(0);
}

int main()
{
   int num = 0;
sem_init(&m, 0, 1); 
   printf("enter number of patients: ");
   scanf("%d",&num);
    pthread_t t[num];
    
    int i = 0;
   
       
   
    struct data d[num];
    for(i = 0;i<num;i++)
    {	
    	d[i].pid = i+1;
    	d[i].result = rand()%2;
        pthread_create(&t[i],NULL,handle,(void*)&d[i]);
    }
	sem_destroy(&m);
    pthread_exit(NULL);
    return 0;

}







