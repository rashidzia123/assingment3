
#include<sys/wait.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<string.h>
#include<semaphore.h>

/*sem_init(&mutex, 0, 1); 
    pthread_t t1,t2; 
    pthread_create(&t1,NULL,thread,NULL); 
    sleep(2); 
    pthread_create(&t2,NULL,thread,NULL); 
    pthread_join(t1,NULL); 
    pthread_join(t2,NULL); 
    sem_destroy(&mutex); */


int main()
{

	sem_t sem1;
	sem_init(&sem1, 0, 1); 
	sem_t sem2;
	sem_init(&sem2, 0, 1); 
	sem_t sem3;
	sem_init(&sem3, 0, 1); 
	sem_wait(&sem3);
    key_t k1= ftok("shmfile",65);
    key_t k2 = ftok("shmfile",65); 
  

    int shmid1 = shmget(k1,1024,0666|IPC_CREAT); 
      int shmid2 = shmget(k2,1024,0666|IPC_CREAT); 

    char *buff1 = (char*) shmat(shmid1,(void*)0,0); 
    char *buff2 = (char*) shmat(shmid2,(void*)0,0); 
	if( fork()==0)
	{
		sem_wait(&sem1);
		FILE *f;
		f = fopen("file1.txt","r");
		char str[11];
		fgets(str,11,f);
		printf("process A got: %s from file1\n",str);
		
		
		strcpy(buff1,str);
		printf("process A copied: %s on buffer1\n",str);
		sem_post(&sem1); 
		fclose(f);
		
	}
	else
	{
		
		if(fork()==0)
		{
	
		sem_wait(&sem1); 
		FILE *f;
		f = fopen("file2.txt","r");
		char str[11];
		fgets(str,11,f);
		printf("process B got: %s from file2\n",str);
		
		strcat(buff1,str);
		printf("process B copied: %s on buffer1\n",str);
		fclose(f);
		sem_post(&sem1); 
		}
		else
		{
		sleep(0.1);
			if(fork()==0)
			{
				sem_wait(&sem2);
				printf("process C: ");
				strcpy(buff2,buff1);
				printf("copied data from buff1 to buff2\n");
				sem_post(&sem2);
			
			}
				else
				{
					sleep(0.1);
					if(fork()==0)
					{
					sem_wait(&sem2);
					
					printf("Process D: printint from buff 2\n");
					printf("buff2: %s\n",buff2);
					
					sem_post(&sem3);
					sem_post(&sem2);

					//exit(0);
					}
					else
					{
					sem_wait(&sem3);
					int s;
					//sem_wait(&sem3);
					printf("parent exiting\n");
					shmdt(buff1); 
					shmctl(shmid1,IPC_RMID,NULL); 
					shmdt(buff2); 
					shmctl(shmid1,IPC_RMID,NULL);
					exit(0);
				}
			}
		}
	}
	
	
	
	

return 0;
}
